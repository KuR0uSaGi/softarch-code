package com.solid.lsp;

public abstract class Shape {

    public abstract int getArea();

}
