package com.solid.book;

public interface Reader {
    public void printToScreen();
}
