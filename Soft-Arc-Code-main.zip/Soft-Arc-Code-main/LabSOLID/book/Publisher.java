package com.solid.book;

public interface Publisher {
    public void printToFile();
}
